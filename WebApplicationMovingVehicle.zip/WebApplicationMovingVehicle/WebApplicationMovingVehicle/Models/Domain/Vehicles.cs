﻿namespace WebApplicationMovingVehicle.Models.Domain
{
    // ApplicationDbContext.cs


    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // Define DbSet for each entity
        public DbSet<Make> Makes { get; set; }
        public DbSet<Model> Models { get; set; }
        public DbSet<Vehicle> Vehicles { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<Truck> Trucks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure relationships, keys, etc.
            // For example:
            modelBuilder.Entity<Vehicle>()
                .HasOne(v => v.Make)
                .WithMany()
                .HasForeignKey(v => v.MakeID);

            modelBuilder.Entity<Vehicle>()
                .HasOne(v => v.Model)
                .WithMany()
                .HasForeignKey(v => v.ModelID);

            // Configure other relationships as needed

            base.OnModelCreating(modelBuilder);
        }
    }

}
}
