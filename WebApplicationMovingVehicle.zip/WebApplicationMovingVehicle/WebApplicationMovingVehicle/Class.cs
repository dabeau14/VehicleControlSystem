﻿namespace WebApplicationMovingVehicle
{
    public class Class
    {
    }
}
public class Make
{
    public int MakeID { get; set; }
    public string MakeName { get; set; }

    public List<Model> Models { get; set; }
}

public class Model
{
    public int ModelID { get; set; }
    public string ModelName { get; set; }
    public Make Make { get; set; }
    public int MakeID { get; set; }

    public List<Vehicle> Vehicles { get; set; }
}

public class Vehicle
{
    public int VehicleID { get; set; }
    public string VIN { get; set; }
    public Make Make { get; set; }
    public int MakeID { get; set; }
    public Model Model { get; set; }
    public int ModelID { get; set; }
    public decimal AverageSpeed { get; set; }
    public DateTime ManufacturedDate { get; set; }

    public void Drive()
    {
        // Drive the vehicle.
    }

    public void Stop()
    {
        // Stop the vehicle.
    }

    public void Reverse()
    {
        // Reverse the vehicle.
    }
}

public class Car : Vehicle
{
    public string Color { get; set; }
    public int NumberOfDoors { get; set; }
    public string FuelType { get; set; } // additional property specific to cars

    public Car()
    {
        // Initialize the FuelType property to a default value.
        FuelType = "Gasoline";
    }
}

public class Truck : Vehicle
{
    public decimal BedLength { get; set; }
    public decimal TowingCapacity { get; set; }
    public int DriveTrain { get; set; } // additional property specific to trucks

    public Truck()
    {
        // Initialize the DriveTrain property to a default value.
        DriveTrain = 2; // 2 = Rear-wheel drive
    }
}
public class CarService
{
    public void CreateCar()
    {
        // Create a new Car object.
        var car = new Car();

        // Set the Color, NumberOfDoors, and FuelType properties.
        car.Color = "Red";
        car.NumberOfDoors = 4;
        car.FuelType = "Gasoline";

        // Save the car object to the database.
        // ...
    }
}
