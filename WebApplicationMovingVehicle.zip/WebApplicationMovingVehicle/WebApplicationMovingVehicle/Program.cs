using Microsoft.EntityFrameworkCore;
using WebApplicationMovingVehicle.Data;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Configure services.
        builder.Services.AddSignalR();
        builder.Services.AddControllersWithViews();
        builder.Services.AddDbContext<MVCDemoDbContext>(options =>
        options.UseSqlServer(builder.Configuration.GetConnectionString(MvcDemoConnectionString)));
        


        // Configure middleware.
        builder.UseRouting();
        builder.UseEndpoints(endpoints =>
        {
            endpoints.MapHub<VehicleHub>("/vehicleHub");
        });

        // Configure routing.
        builder.MapDefaultControllerRoute();

        var app = builder.Build();

        app.Run();
    }
}
