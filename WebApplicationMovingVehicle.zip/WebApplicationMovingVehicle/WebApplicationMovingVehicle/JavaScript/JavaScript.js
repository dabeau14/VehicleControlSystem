﻿// vehicles.js

document.addEventListener("DOMContentLoaded", function () {
    // Create a connection to the SignalR hub
    var connection = new signalR.HubConnectionBuilder()
        .withUrl("/myhub") // Make sure this matches the hub endpoint in Startup.cs
        .configureLogging(signalR.LogLevel.Information)
        .build();

    connection.start().then(function () {
        console.log("SignalR Connected");
    }).catch(function (err) {
        return console.error(err.toString());
    });

    // Handle incoming messages from the server
    connection.on("ReceiveMessage", function (message) {
        console.log("Received message: " + message);
        // You can update the UI here based on the incoming data
    });

    // Add more JavaScript code as needed for your application
});

    <script src="~/js/vehicles.js"></script>
